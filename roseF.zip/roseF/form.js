document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");
    if (!form) return;
  
    const nameInput   = form.querySelector("#fullname");
    const emailInput  = form.querySelector("#email");
    const serviceBoxes = form.querySelectorAll("input[name='services[]']");
    const successMsg = document.getElementById("form-success-msg");
  
    const showError = (el, message) => {
      let err = el.parentElement.querySelector(".error-msg");
      if (!err) {
        err = document.createElement("span");
        err.className = "error-msg";
        err.style.color = "crimson";
        err.style.fontSize = "0.85rem";
        el.parentElement.appendChild(err);
      }
      err.textContent = message;
    };
  
    const clearError = (el) => {
      const err = el.parentElement.querySelector(".error-msg");
      if (err) err.textContent = "";
    };
  
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      let hasError = false;
  
      const nameVal = nameInput.value.trim();
      if (nameVal.length < 3) {
        showError(nameInput, "Name must be at least 3 characters");
        hasError = true;
      } else {
        clearError(nameInput);
      }
  
      const emailVal   = emailInput.value.trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailVal)) {
        showError(emailInput, "Please enter a valid email");
        hasError = true;
      } else {
        clearError(emailInput);
      }
  
      const serviceChecked = Array.from(serviceBoxes).some(chk => chk.checked);
      if (!serviceChecked) {
        showError(serviceBoxes[0], "Please select at least one service");
        hasError = true;
      } else {
        clearError(serviceBoxes[0]);
      }
  
      if (!hasError) {
        successMsg.style.display = "block";
        form.reset();
      } else {
        successMsg.style.display = "none";
      }
    });
  });
  